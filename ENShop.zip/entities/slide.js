class Slide {

    constructor(index, src, id, desc, nom) {
        this.index = index;
        this.src = src;
        this.IdProducto = id;
        this.Descripcion = desc;
        this.Nombre = nom;
    }

}

module.exports = Slide;